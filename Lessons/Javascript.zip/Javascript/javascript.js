function Section2() {
    // Replaced the text that had the id 'sec2_text'
    document.getElementById('sec2_text').innerHTML = 'Mich applied for a job and is asked to go in for an interview!';
}

/* 
TODO: Implement the Section 3 function


*/

function Section4_1() {
    document.getElementById('sec4_text').innerHTML = 'Mich can be extra full now when walking to the interview!';

    // Replaced the img that had the id 'sec4_img'
    document.getElementById('sec4_img').src = 'Images/Mich_dress.png';

    // Replaced the alt text that had the id 'sec4_img'
    document.getElementById('sec4_img').alt = "Mich in a dress";
}

function Section4_2() {
    document.getElementById('sec4_text').innerHTML = 'Mich looks stylish and unique now!';
    document.getElementById('sec4_img').src = 'Images/Mich_suit.png';
    document.getElementById('sec4_img').alt = "Mich in a suit";
}

/* 
TODO: Implement the Section 5 functions


*/



// The Position of list (all lists start at 0, not at 1)
let sec6_pos = 0;

// Created a list of images to sequence through
const run_images = ['Images/Mich_run1.png', 'Images/Mich_run2.png', 'Images/Mich_run3.png'];

function Section6() {
    
    // Changes the text of the button
    document.getElementById('sec6_btn').innerHTML = 'Keep clicking to run!';

    document.getElementById('sec6_img').src = run_images[sec6_pos];
    document.getElementById('sec6_img').alt = "Mich runs";

    // Changes the position of the list
    sec6_pos++

    // If the position reaches the end of the list, position starts back at 0
    if(sec6_pos >= run_images.length) {
        sec6_pos = 0
    } 
}


/* 
TODO: Implement the Section 7 functions


*/

let sec8_pos = 0;
const sleep_images = ['Images/Mich_sleep0.png', 'Images/Mich_sleep1.png', 'Images/Mich_sleep2.png', 'Images/Mich_sleep3.png'];

function Section8() {

    function Repeat() {
        document.getElementById('sec8_img').src = sleep_images[sec8_pos];
        document.getElementById('sec8_img').alt = "Mich sleeps";
            
        sec8_pos++
        if(sec8_pos >= sleep_images.length) {
            sec8_pos = 0
        } 
    }

    setInterval(Repeat, 500)
    
}


/* 
TODO: Implement the Section 9 functions


*/

/* 
TODO: Implement the Section 10 functions


*/