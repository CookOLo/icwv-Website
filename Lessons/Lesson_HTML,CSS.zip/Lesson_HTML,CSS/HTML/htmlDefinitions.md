SECTION 1 & 2
<h1></h1>: Header Tags
    Exp: <h1>Title: How to eat eggs</h1>
<p></p1>: Paragraph Tags
    Exp: <p>Four scores and seven years ago, our fathers brought forth on this continent...</p>
<!-- ... -->: Comment (code won't recognize this and execute it)
    - This is truly meant for you or anyone else who is reading your code to better understand it.

SECTION 3
<b></b>: bold
    Exp: <b>NICE!</b>
<i></i>: italicize
    Exp: <i>cool</i>
<del></del>: linethrough the text
    Exp: <del>there's a line through me</del>
<ins></ins>: underline
    Exp: <ins>this text has an underline</ins>
<mark></mark>: highlight
    Exp: <mark>this text is highlighted</mark>

SECTION 4
<img src="">: adds an image
    - the 'src=""' is the location within your file system
    - Exp: <img src="/Desktop/pic.jpg">
<img alt="">: adds alternative text to the image
    - this is for accessibility 
    - Exp: <img src="/Desktop/pic.jpg" alt="This is a picture">

