// Gets code from React Library

// For Section 1
import { useState } from "react";

// For Section 2
import { useId } from "react";  

// For Section 3
const script = document.createElement('script');
script.src = 'https://cdn.jsdelivr.net/npm/js-confetti@latest/dist/js-confetti.browser.js';
script.onload = () => {
    window.confetti = new window.JSConfetti();
  };
document.head.appendChild(script);


// Couldn't import because it wasn't downloaded like how 'React' is already downloaded here
// Needed to tell the code where to download it from
//const script = document.createElement('script');
//script.src = 'https://cdn.jsdelivr.net/npm/js-confetti@0.12.0/dist/index.min.js';
//document.head.appendChild(script);

export default function App() {

  {/* SECTION 1 (FUNCTION) */}
  const [text, setText] = useState(""); // "text" is what is shown on screen, "setText" is how to change 
  const [Sec1_name, Sec1_setName]= useState(""); // "name" is what is shown on screen, "setName" is how to change
  const [Sec1_message, Sec1_setMessage]= useState(""); // "message" is what is shown on screen, "setMessage" is how to change

  
  // Gives choices for what's inside the text box
  function Sec1_Write() {
      if(text == "Yes" || text == "yes") {
        Sec1_setName("LlamaEater76:");
        Sec1_setMessage("Oh wow, do you always do what everyone tells you to do. How sad.");
      } else if(text == "No" || text == "no") {
        Sec1_setName("LlamaEater76:");
        Sec1_setMessage("Bruh.");
      } else {
        Sec1_setName("LlamaEater76:");
        Sec1_setMessage("Okayyyy... not the response I was hoping for. But whatever.");
      }
    }
  {/* SECTION 1 END */}



  {/* SECTION 2 (FUNCTION) */}
  {/* TODO: Write 'Sec2_Write' Function*/} 
  

  {/* SECTION 2 END */}


  {/* SECTION 3 (FUNCTION) */}
  const [Sec3_name, Sec3_setName]= useState("");
  const [Sec3_message, Sec3_setMessage]= useState("");
  const id = useId();

  function Sec3_Write() {
        Sec3_setName("Automated Vampire System:");
        Sec3_setMessage("Here is your ID: '" + id + "'");
    }
  {/* SECTION 3 END */}

  {/* SECTION 4 (FUNCTION) */}
  {/* TODO: Write 'Sec4_Write' Function*/} 
  

  {/* SECTION 4 END */}

  {/* SECTION 5 (FUNCTION) */}
  
  const jsConfetti = new JSConfetti()
  
  function Sec5() {
    jsConfetti.addConfetti();
  }
  
  {/* SECTION 5 END */} 

  {/* SECTION 6 (FUNCTION) */}
  {/* TODO: Write 'Sec6' Function*/} 
  

  {/* SECTION 6 END */}

  return (
    <div style={{
        backgroundColor: "black",
        minHeight: "100vh",
        color: "#199515",
        fontFamily: "Courier New"}}>
      <h2>Vampire Hunters Industries (TM) COMM Link</h2>
      <h4><b>Unathorized access will lead to termination</b></h4>
      <hr style={{borderColor: "#199515"}}></hr>
      <hr style={{borderColor: "#199515"}}></hr>
      <br></br>
      
      {/* SECTION 1 (JSX) */}
      <p><b>LlamaEater76</b>: Hey are you there?</p>
      <p><b>LlamaEater76</b>: If you are, could you please type "Yes" in the text box below and then press submit?</p>

      {/* Creates the text-input box */}
      <label> 
        <textarea
          style={{
            backgroundColor: "black",
            color: "#199515",
            borderColor: "#199515",
            fontFamily: "Courier New"}}
          rows="1"
          cols="20"
          placeholder="Yes or no?..."
          value={text} // remembers the text in textarea
          onChange={(e) => setText(e.target.value)} // gets the most updated text in textarea
        />
      </label>

      <br></br>
      <button onClick={Sec1_Write} style={{
        backgroundColor: "#394131ff",
        color: "#199515",
        fontFamily: "Courier New"}}>Submit</button>

      <br></br>
      <p><b>{Sec1_name}</b> {Sec1_message}</p>
      <hr style={{borderColor: "#199515"}}></hr>

      {/* SECTION 1 END */}

      {/* SECTION 2 (JSX) */}
      {/* 
      <p><b>LlamaEater76</b>: Whatever. Hey, just to confirm: you aren't a vampire right?</p>
    
      // TODO: Insert your own box with choices to be had 


      */}

      {/* SECTION 2 END */}
    
      {/* SECTION 3 (JSX) */}
      <hr style={{borderColor: "#199515"}}></hr>
      <p><b>LlamaEater76</b>: You know, it didn't even matter if you were a vampire or not.</p>
      <p><b>LlamaEater76</b>: Actually, what's important is that you need to hack into this evil vampire hunter company.</p>
      
      <button onClick={Sec3_Write} style={{
        backgroundColor: "#394131ff",
        color: "#199515",
        fontFamily: "Courier New"}}>Press me loser</button>
      
      <p><b>{Sec3_name}</b> {Sec3_message}</p>
      <hr style={{borderColor: "#199515"}}></hr>
      {/* SECTION 3 END */}

      {/* SECTION 4 (JSX) */}
      {/* 
      <p><b>LlamaEater76</b>: Bruh, why'd you get one for yourself. Get an ID for me now</p>
      
      // TODO: Insert your own button that creates another ID -- but make the ID different than before
      
      */}

      {/* SECTION 4 END */}

      {/* SECTION 5 (JSX) */}
      <hr style={{borderColor: "#199515"}}></hr>
      <p><b>LlamaEater76</b>: Great! Now that we can hack into this evil VAMPIRE HUNTING COMPANY</p>
      <p><b>LlamaEater76</b>: To celebrate: Let's throw some confetti around!!!</p>
      
      <button onClick={Sec5} style={{
        backgroundColor: "#394131ff",
        color: "#199515",
        fontFamily: "Courier New"}}>🎉🎉🎉Confetti Time🎉🎉🎉</button>
      
      {/* SECTION 5 END */}

      {/* SECTION 6 (JSX) */}
      {/*
      <p><b>LlamaEater76</b>: Bruh, why'd you get one for yourself. Get an ID for me now</p>

      // TODO: Create another confetti button, but customize it!
      // TODO: Read up the documentation and learn how to customize it
      // Website: https://www.npmjs.com/package/js-confetti 



      */}
      {/* SECTION 6 END */}
    </div>
  );
}

